
import { SavingsView } from '@/components/savings-view';

export default function SavingsPage() {
  return <SavingsView />;
}
