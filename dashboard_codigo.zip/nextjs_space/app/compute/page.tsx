
'use client';

import { ComputeMetricsView } from '@/components/compute-metrics-view';

export default function ComputePage() {
  return <ComputeMetricsView />;
}
