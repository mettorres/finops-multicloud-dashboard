
import { IdleResourcesView } from '@/components/idle-resources-view';

export default function IdleResourcesPage() {
  return <IdleResourcesView />;
}
