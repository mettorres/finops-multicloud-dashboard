
import { TrendsView } from '@/components/trends-view';

export default function TrendsPage() {
  return <TrendsView />;
}
