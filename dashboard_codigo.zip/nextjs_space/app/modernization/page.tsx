
'use client';

import { ModernizationView } from '@/components/modernization-view';

export default function ModernizationPage() {
  return <ModernizationView />;
}
