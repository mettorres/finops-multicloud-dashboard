
import { CloudSpecificView } from '@/components/cloud-specific-view';

export default function AWSPage() {
  return <CloudSpecificView cloudProvider="aws" />;
}
