
import { CloudSpecificView } from '@/components/cloud-specific-view';

export default function GCPPage() {
  return <CloudSpecificView cloudProvider="gcp" />;
}
