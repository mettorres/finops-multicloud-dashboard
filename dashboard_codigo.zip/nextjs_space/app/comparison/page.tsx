
import { ComparisonView } from '@/components/comparison-view';

export default function ComparisonPage() {
  return <ComparisonView />;
}
