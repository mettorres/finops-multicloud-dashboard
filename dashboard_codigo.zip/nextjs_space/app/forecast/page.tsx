
'use client';

import { ForecastView } from '@/components/forecast-view';

export default function ForecastPage() {
  return <ForecastView />;
}
