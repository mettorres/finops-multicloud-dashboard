
import { CloudSpecificView } from '@/components/cloud-specific-view';

export default function AzurePage() {
  return <CloudSpecificView cloudProvider="azure" />;
}
