
'use client';

import { StorageMetricsView } from '@/components/storage-metrics-view';

export default function StoragePage() {
  return <StorageMetricsView />;
}
