
import { RecommendationsView } from '@/components/recommendations-view';

export default function RecommendationsPage() {
  return <RecommendationsView />;
}
