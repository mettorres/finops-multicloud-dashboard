
'use client';

import { ExecutiveDashboard } from '@/components/executive-dashboard';

export default function ExecutivePage() {
  return <ExecutiveDashboard />;
}
