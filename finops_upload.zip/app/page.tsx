import { DashboardView } from '@/components/dashboard-view';

export default function HomePage() {
  return <DashboardView />;
}